﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Collections;
using System.IO;
using System.Text.RegularExpressions;



namespace TheDotFactory
{


    public class CharacterGenerationInfo
    {
        // pointer the font info
        public FontInfo fontInfo;

        // the character
        public char character;

        // the original bitmap
        public Bitmap bitmapOriginal;

        // the bitmap to generate into a string (flipped, trimmed - if applicable)
        public Bitmap bitmapToGenerate;

        // value of pages (vertical 8 bits), in serial order from top of bitmap
        public ArrayList pages;

        // character size
        public int width;
        public int height;

        // offset into total array
        public int offsetInBytes;
    }
    public class FontInfo
    {
        public int charHeight;
        public char startChar;
        public char endChar;
        public CharacterGenerationInfo[] characters;
        public Font font;
        public string generatedChars;
    }

    partial class RLE_Class
    {
        private Font m_font;

        
        private int m_TotalCharacters;
        private int m_CharacterCounter;

        
        private int[] m_HorizontalRleByteCountArray;
        private int[] m_VerticalRleByteCountArray;

        byte[][] m_ArrayOfVerticalArrays;
        byte[][] m_ArrayOfHorizontalArrays;

        private int[] m_EncodingMethodArray;
        private char[] m_CharValueArray;
        private int[] m_CharWidthArray;
        private int[] m_CharHeightArray;
        private int[] m_StdBitmapSizeArray;
        private int[] m_ContinuousBitsSizeArray;
        

        //private char m_CharON = '0';
        //private char m_CharOFF = '-';

        private string m_StringData = "";

        //private string m_VisualizerString = "";

        // Class methods

        // public void Test(int Test)
        // public void Initialize(int TotalCharacters, Font font)
        // public string GetTextData()

        // public void generateDataRLE(int width, int height, ArrayList pages, OutputConfiguration OutputConfig, char ThisChar)
        // private void FillVerticalPixelArray(int width, int height, int colCount, int rowCount, ArrayList pages, bool[] VertPixelArray)
        // private void FillHorizontalPixelArray(int width, int height, int colCount, int rowCount, ArrayList pages, bool[] HorizPixelArray)
        // Private int GetRleByteCount(int TotalPixels, bool[] PixelArray)
        // private int FillRleByteArray(int TotalPixels, bool[] PixelArray, byte[] ByteArray)

        // private string CreateHorizontalVisualizerString(char ON, char OFF, int width, int height, byte[] ByteArray, int ByteCount)
        // private string CreateVerticalVisualizerString(char ON, char OFF, int width, int height, byte[] ByteArray, int ByteCount)
        // public string GetHorizontalVisualizerString()
        // private string CreateRleByteString(char ThisChar, int ByteCount, int Format, byte[] ByteArray, string EncodingName)
        // public string GetCodeString(int EncodingType, int OutputBase)
    }
    


    partial class RLE_Class
    {
        public void Initialize(int TotalCharacters, Font font)
        {

            m_font = font;
            m_CharacterCounter = 0;
            m_TotalCharacters = TotalCharacters;
           
   //         m_CharactersCreatedSofar = 0;


            m_HorizontalRleByteCountArray = new int[m_TotalCharacters];
            m_VerticalRleByteCountArray = new int[m_TotalCharacters];

            m_ArrayOfVerticalArrays = new byte[m_TotalCharacters][];
            m_ArrayOfHorizontalArrays = new byte[m_TotalCharacters][];

            m_CharValueArray = new char[m_TotalCharacters];
            m_CharWidthArray = new int[m_TotalCharacters];
            m_CharHeightArray = new int[m_TotalCharacters];
            m_StdBitmapSizeArray = new int[m_TotalCharacters];
            m_EncodingMethodArray = new int[m_TotalCharacters];
            m_ContinuousBitsSizeArray = new int[m_TotalCharacters];

            // m_StringArray = new string[m_TotalCharacters];
        }
    }

    partial class RLE_Class
    {
        public void FillInternalCharacterArrays(int width, int height, ArrayList pages, OutputConfiguration OutputConfig, char ThisChar)
        {
            int colCount = (OutputConfig.bitLayout == OutputConfiguration.BitLayout.RowMajor) ? (width + 7) / 8 : width;
            int rowCount = (OutputConfig.bitLayout == OutputConfiguration.BitLayout.RowMajor) ? height : (height + 7) / 8;


            int TotalPixels = width * height;

            // Create a bool arrays of ONLY the pixels that are needed to create the font character.
            bool[] HorizPixelArray = new bool[TotalPixels];
            bool[] VertPixelArray = new bool[TotalPixels];

            // Fill the bool arrays from the page
            FillHorizontalPixelArray(width, height, colCount, rowCount, pages, HorizPixelArray);
            FillVerticalPixelArray(width, height, colCount, rowCount, pages, VertPixelArray);

            // work-out and get the RLE Byte count by calling 'FillRleByteArray' with a NULL array
            int HorizontalRleByteCount = FillRleByteArray(TotalPixels, HorizPixelArray, null);
            int VerticalRleByteCount = FillRleByteArray(TotalPixels, VertPixelArray, null);

            //         byte[] HorizontalByteArray = new byte[HorizontalRleByteCount];
            //        byte[] VerticalByteArray = new byte[VerticalRleByteCount];

            // Add a new RLE byte array of the correct byte count to the Jagged-Array 
            m_ArrayOfHorizontalArrays[m_CharacterCounter] = new byte[HorizontalRleByteCount];
            m_ArrayOfVerticalArrays[m_CharacterCounter] = new byte[VerticalRleByteCount];



            //          FillRleByteArray(TotalPixels, HorizPixelArray, HorizontalByteArray);
            //          FillRleByteArray(TotalPixels, VertPixelArray, VerticalByteArray);

            // Fill the RLE byte array created in the Jagged-Array
            FillRleByteArray(TotalPixels, HorizPixelArray, m_ArrayOfHorizontalArrays[m_CharacterCounter]);
            FillRleByteArray(TotalPixels, VertPixelArray, m_ArrayOfVerticalArrays[m_CharacterCounter]);



            // Store the Horizontal & Vertical RLE byte count created for this character
            m_HorizontalRleByteCountArray[m_CharacterCounter] = HorizontalRleByteCount;
            m_VerticalRleByteCountArray[m_CharacterCounter] = VerticalRleByteCount;

            // Store the Width, Height and Ascii code for the character
            m_CharValueArray[m_CharacterCounter] = ThisChar;
            m_CharWidthArray[m_CharacterCounter] = width;
            m_CharHeightArray[m_CharacterCounter] = height;

            // Work-out and store the size of a Standard Bitmap for the character
            m_StdBitmapSizeArray[m_CharacterCounter] = colCount * rowCount;

            // Work-out and store the size of a Continuous Bits Bitmap for the character
            int Count = TotalPixels / 8;
            int Remainder = TotalPixels - (Count * 8);


            if (Remainder == 0)
            {
                m_ContinuousBitsSizeArray[m_CharacterCounter] = Count;
            }
            else
            {
                m_ContinuousBitsSizeArray[m_CharacterCounter] = Count + 1;
            }


            //m_StringData += CreateRleByteString(ThisChar, HorizontalRleByteCount, 16, HorizontalByteArray, "Horizontal");

            // m_StringData += CreateRleByteString(ThisChar, VerticalRleByteCount, 16, VerticalByteArray, "Vertical");

            //m_StringData += CreateHorizontalVisualizerString(m_CharON, m_CharOFF, width, height, HorizontalByteArray, HorizontalRleByteCount);

            //m_StringData += CreateVerticalVisualizerString(m_CharON, m_CharOFF, width, height, VerticalByteArray, VerticalRleByteCount);


            // we have finished creating and filling all internal Vertical & Horizontal arrays
            // for this character and so it's time to increment the internal character counter.
            m_CharacterCounter++;


        }// End of generateDataRLE()
    }// End of partial class RLE_Class


    partial class RLE_Class
    {
        public string GetStatisticsString()
        {
            if (m_TotalCharacters == 0)
            {
                return "";
            }
            int CharCounter;


            int ThisHeight = m_CharHeightArray[0];
            int ThisWidth = m_CharWidthArray[0];
            char ThisChar = m_CharValueArray[0];

            int HighestValue = ThisHeight;
            int ShortestValue = ThisHeight;
            int WidestValue = ThisWidth;
            int NarrowestValue = ThisWidth;

            char HighestChar = ThisChar;
            char ShortestChar = ThisChar;
            char WidestChar = ThisChar;
            char NarrowestChar = ThisChar;

            int HorizontalByte;
            int VerticalByte;
            int TotalHorizontalRleBytes = 0;
            int TotalVerticalRleBytes = 0;
            int TotalMixedModeRleBytes = 0;

            int TotalContinuousBits = 0;
            int TotalStdBytes = 0;

            int FontSize = (int)Math.Round(m_font.SizeInPoints);
            string FontName = m_font.Name;
            string TempString = "";

            WidestValue = m_CharWidthArray[0]; 

            for (CharCounter = 0; CharCounter < m_TotalCharacters; CharCounter++)
            {
                ThisWidth = m_CharWidthArray[CharCounter];
                ThisHeight = m_CharHeightArray[CharCounter];

                if (ThisWidth > WidestValue)
                {
                    WidestValue = ThisWidth;
                    WidestChar = m_CharValueArray[CharCounter];
                }

                if (ThisWidth < NarrowestValue)
                {
                    NarrowestValue = ThisWidth;
                    NarrowestChar = m_CharValueArray[CharCounter];
                }

                if (ThisHeight > HighestValue)
                {
                    HighestValue = ThisHeight;
                    HighestChar = m_CharValueArray[CharCounter];
                }

                if (ThisHeight < ShortestValue)
                {
                    ShortestValue = ThisHeight;
                    ShortestChar = m_CharValueArray[CharCounter];
                }
               
              
            }

            for (CharCounter = 0; CharCounter < m_TotalCharacters; CharCounter++)
            {
                HorizontalByte = m_HorizontalRleByteCountArray[CharCounter];
                VerticalByte = m_VerticalRleByteCountArray[CharCounter];

                TotalHorizontalRleBytes = TotalHorizontalRleBytes + HorizontalByte;
                TotalVerticalRleBytes = TotalVerticalRleBytes + VerticalByte;

                if (HorizontalByte > VerticalByte)
                {
                    TotalMixedModeRleBytes = TotalMixedModeRleBytes + VerticalByte;
                }
                else
                {
                    TotalMixedModeRleBytes = TotalMixedModeRleBytes + HorizontalByte;
                }

                TotalContinuousBits = TotalContinuousBits + m_ContinuousBitsSizeArray[CharCounter];

                TotalStdBytes = TotalStdBytes + m_StdBitmapSizeArray[CharCounter];
            }
            TempString = "\r\n\t";
            TempString += "\r\n//\t      ***    Font Encoding Statistics    *** ";
            TempString += "\r\n//\t";
            TempString += "\r\n//\t This font has been encoded with 'The Dot Factory'";
            TempString += "\r\n//\t using Run-Length-Encoding (RLE) from a ";
            TempString += Convert.ToString(FontSize, 10);
            TempString += "-Pt";
            // TempString += "\r\n//\t ";
            TempString += "\r\n//\t TrueType font called \"";
            TempString += FontName;
            TempString += "\"";

            TempString += "\r\n";
       //     TempString += "\r\n//\t\t\t\t -\t-\t-\t";

            TempString += "\r\n//\t'";
            TempString += NarrowestChar;
            TempString += "' (Ascii ";
            TempString += Convert.ToString(NarrowestChar, 10);
            TempString += ") has the smallest width at ";
            TempString += Convert.ToString(NarrowestValue, 10);
            TempString += " Pixels Wide";

            TempString += "\r\n//\t'";
            TempString += WidestChar;
            TempString += "' (Ascii ";
            TempString += Convert.ToString(WidestChar, 10);
            TempString += ") has the greatest width at ";
            TempString += Convert.ToString(WidestValue, 10);
            TempString += " Pixels Wide";

            TempString += "\r\n//\t'";
            TempString += ShortestChar;
            TempString += "' (Ascii ";
            TempString += Convert.ToString(ShortestChar, 10);
            TempString += ") has the smallest height at ";
            TempString += Convert.ToString(ShortestValue, 10);
            TempString += " Pixels high";

            TempString += "\r\n//\t'";
            TempString += HighestChar;
            TempString += "' (Ascii ";
            TempString += Convert.ToString(HighestChar, 10);
            TempString += ") has the greatest height at ";
            TempString += Convert.ToString(HighestValue, 10);
            TempString += " Pixels high";

            

         

            TempString += "\r\n";
            

            TempString += "\r\n//\t The total Horizontal RLE bytes created for this font = ";
            TempString += Convert.ToString(TotalHorizontalRleBytes, 10);

            TempString += "\r\n//\t The total Vertical RLE bytes created for this font = ";
            TempString += Convert.ToString(TotalVerticalRleBytes, 10);

            TempString += "\r\n//\t The total Vert+Horiz RLE bytes created for this font = ";
            TempString += Convert.ToString(TotalMixedModeRleBytes, 10);

            TempString += "\r\n//\t The total Continuous Bitmap bytes created for this font = ";
            TempString += Convert.ToString(TotalContinuousBits, 10);

            TempString += "\r\n//\t The total Standard Bitmap bytes created for this font = ";
            TempString += Convert.ToString(TotalStdBytes, 10);
            TempString += "\r\n\t";

            TempString += m_StringData;

            return TempString;
        }
    }

   



    partial class RLE_Class
    {
        public string GetCodeString(int EncodingType, int OutputBase)
        {
            // EncodingType (0= Standard Bitmap, 1= Statistics, 2= continuous bits, 3= RLE-Vertical, 4= RLE-Horizontal 5= RLE-Vert+Horiz )
            // Continuous bits Encoding to be added later

            if (EncodingType < 3 || EncodingType > 5)
            {
                return "Error in :- GetCodeString(int EncodingType)";
            }

            int Base10 = 10;

            int Base = 16;
            int WidthBase = 10;
            int HeightBase = 10;
            

            int WidthValue;
            int HeightValue;

            int ColumnWidth = 5;
            int ColumnLoop = 0;
            int CharCounter;
            string ByteArrayName = "Chr";
            string TempString;

            string OutputString = "";

            string CharacterIndexString = "\r\n// The 'CharacterIndexArray' Resolves the Index of a character.";
            CharacterIndexString += "\r\n// It is useful when only a 'partial' Character set is generated.";
            CharacterIndexString += "\r\n// Search this array for the ASCII character value you wish to print.";
            CharacterIndexString += "\r\n// If you find the value, the index of where you found it will be";
            CharacterIndexString += "\r\n// the zero based index of most other arrays pertaining to ";
            CharacterIndexString += "\r\n// that particular ASCII character.";
            CharacterIndexString += "\r\n"; 
            CharacterIndexString += "\r\n// If you do NOT find the ASCII character value, Then that character";
            CharacterIndexString += "\r\n// was NOT encoded in the font.";
            CharacterIndexString += "\r\n\r\nconst unsigned char CharacterIndexArray[";
            CharacterIndexString += Convert.ToString(m_TotalCharacters, 10);
            CharacterIndexString += "] = \r\n{\r\n\t";

            string EncodingMethordArrayString = "\r\n// The 'EncodingMethodArray' indicates the RLE method used to";
            EncodingMethordArrayString += "\r\n// encode each character (1 = Vertical,  0 = Horizontal)";
            EncodingMethordArrayString += "\r\n// It is useful when the font uses both Vertical & Horizontal Encoding";
            EncodingMethordArrayString += "\r\n\r\nconst unsigned char EncodingMethodArray[";
            EncodingMethordArrayString += Convert.ToString(m_TotalCharacters, 10);
            EncodingMethordArrayString += "] = \r\n{\r\n\t";

            string WidthArrayString = "\r\n\r\n// The 'Char-Width-Array'";
            WidthArrayString += "\r\n// This array supports character widths up to 255 pixels.";
            WidthArrayString += "\r\nconst unsigned char CharWidthArray[";
            WidthArrayString += Convert.ToString(m_TotalCharacters, 10);
            WidthArrayString += "] = \r\n{\r\n\t";

            string HeightArrayString = "\r\n\r\n// The 'Char-Height-Array'";
            HeightArrayString += "\r\n// This array supports character Heights up to 255 pixels.";
            HeightArrayString += "\r\nconst unsigned char CharHeightArray[";
            HeightArrayString += Convert.ToString(m_TotalCharacters, 10);
            HeightArrayString += "] = \r\n{\r\n\t";



            string ArrayOfArraysString = "\r\n\r\nconst unsigned char* ArrayOfArrays[";
            ArrayOfArraysString += Convert.ToString(m_TotalCharacters, 10);
            ArrayOfArraysString += "] = \r\n{\r\n\t";

            string MixedWidthAndEncodingArrayString = "\r\n\r\n// The 'Mixed-Width-And-Encoding-Array'";
            MixedWidthAndEncodingArrayString += "\r\n// It is useful when the font uses both Vertical & Horizontal Encoding";
            MixedWidthAndEncodingArrayString += "\r\n// This array is only valid for font widths less than 128 pixels";
            MixedWidthAndEncodingArrayString += "\r\n// The MSB (bit 7) indicates encoding method (1 = Vertical,  0 = Horizontal)";
            MixedWidthAndEncodingArrayString += "\r\n// Bits 0-6 represent the character width.";
            MixedWidthAndEncodingArrayString += "\r\nconst unsigned char MixedWidthAndEncodingArray[";
            MixedWidthAndEncodingArrayString += Convert.ToString(m_TotalCharacters, 10);
            MixedWidthAndEncodingArrayString += "] = \r\n{\r\n\t";

            string OffsetArrayString = "\r\n\r\n// The 'Offset-Array'";
            OffsetArrayString += "\r\n// When your font is stored in one Large-Array the OffsetArray,";
            OffsetArrayString += "\r\n// holds each characters byte offset count into the Large-Array.";
            OffsetArrayString += "\r\n// The last value is a 'dummy' value used to define the last characters length.";
            OffsetArrayString += "\r\nconst unsigned int OffsetArray[";
            OffsetArrayString += Convert.ToString((m_TotalCharacters +1), 10);
            OffsetArrayString += "] = \r\n{\r\n\t";

            string RleByteCountString = "\r\n\r\n// The 'ByteCount-Array'";
            RleByteCountString += "\r\n// This array holds the number of bytes used to code each characters pixels.";
            RleByteCountString += "\r\n// If you are using one Large-Array these values can be determined from";
            RleByteCountString += "\r\n// the OffsetArray, but if you are using the ArrayOfArrays method, this array";
            RleByteCountString += "\r\n// can be used to determine the size of the arrays inside the ArrayOfArrays.";
            RleByteCountString += "\r\nconst unsigned int ByteCount[";
            RleByteCountString += Convert.ToString((m_TotalCharacters), 10);
            RleByteCountString += "] = \r\n{\r\n\t";

                  

//            m_HorizontalRleByteCountArray;
//            m_VerticalRleByteCountArray;
//            m_CharacterValue;
//            m_CharWidthArray;
//            m_CharHeightArray;

            int HorizontalByteCount;
            int VerticalByteCount;
            int RleByteCount;
            int OffsetCount = 0;
/*
            for (CharCounter = 0; CharCounter < m_TotalCharacters; CharCounter++)
            {
                
                HorizontalByteCount = m_HorizontalRleByteCountArray[CharCounter];
                VerticalByteCount = m_VerticalRleByteCountArray[CharCounter];

                if(EncodingType == 3)
                {
                    m_EncodingMethodArray[CharCounter] = 1;
                }
                else
                {
                    if (EncodingType == 4)
                    {
                        m_EncodingMethodArray[CharCounter] = 0;
                    }
                    else
                    {
                        if (VerticalByteCount <= HorizontalByteCount)
                        {
                            m_EncodingMethodArray[CharCounter] = 1;
                        }
                        else
                        {
                            m_EncodingMethodArray[CharCounter] = 0;
                        }
                    }
                }

                

                
            }
 */

            ColumnLoop = 0;

            for (CharCounter = 0; CharCounter < m_TotalCharacters; CharCounter++)
            {
                ColumnLoop++;

                OffsetArrayString += Convert.ToString(OffsetCount, 10);

                // Create an array of ASCII Character codes to use a Index into other arrays
                CharacterIndexString += Convert.ToString(m_CharValueArray[CharCounter], Base10);
                

                HorizontalByteCount = m_HorizontalRleByteCountArray[CharCounter];
                VerticalByteCount = m_VerticalRleByteCountArray[CharCounter];


                if (EncodingType == 3) //3= RLE-Vertical
                {
                    m_EncodingMethodArray[CharCounter] = 1;
                    OffsetCount = OffsetCount + VerticalByteCount;
                    RleByteCount = VerticalByteCount;
                }
                else
                {
                    if (EncodingType == 4) // 4= RLE-Horizontal 
                    {
                        m_EncodingMethodArray[CharCounter] = 0;
                        OffsetCount = OffsetCount + HorizontalByteCount;
                        RleByteCount = HorizontalByteCount;
                    }
                    else
                    {
                        if (VerticalByteCount <= HorizontalByteCount) // 5= RLE-Vert+Horiz
                        {
                            m_EncodingMethodArray[CharCounter] = 1;
                            OffsetCount = OffsetCount + VerticalByteCount;
                            RleByteCount = VerticalByteCount;
                        }
                        else
                        {
                            m_EncodingMethodArray[CharCounter] = 0;
                            OffsetCount = OffsetCount + HorizontalByteCount;
                            RleByteCount = HorizontalByteCount;
                        }
                    }
                }


/*
                if (VerticalByteCount <= HorizontalByteCount)
                {
                    
                    OffsetCount = OffsetCount + VerticalByteCount;
                    RleByteCount = VerticalByteCount;
                }
                else
                {
                    
                    OffsetCount = OffsetCount + HorizontalByteCount;
                    RleByteCount = HorizontalByteCount;
                }
*/

                RleByteCountString += Convert.ToString(RleByteCount, 10);


                TempString = Convert.ToString(m_CharValueArray[CharCounter], Base);
                TempString = TempString.ToUpper();

                ArrayOfArraysString += ByteArrayName;
                ArrayOfArraysString += TempString;

                EncodingMethordArrayString += m_EncodingMethodArray[CharCounter];

                WidthValue = m_CharWidthArray[CharCounter];

                WidthArrayString += Convert.ToString(WidthValue, WidthBase);

                HeightValue = m_CharHeightArray[CharCounter];
                HeightArrayString += Convert.ToString(HeightValue, HeightBase);

                

                if (m_EncodingMethodArray[CharCounter] == 1)
                {
                    WidthValue = WidthValue + 128;
                }

                MixedWidthAndEncodingArrayString += Convert.ToString(WidthValue, WidthBase);

                if(ColumnLoop == ColumnWidth)
                {
                    if (CharCounter == (m_TotalCharacters - 1))
                    {
                        CharacterIndexString += "\r\n};";
                        MixedWidthAndEncodingArrayString += "\r\n};";
                        EncodingMethordArrayString += "\r\n};";
                        RleByteCountString += "\r\n};";
                        

                        // Add one Last dummy Offset Value
                        OffsetArrayString += ", \r\n\t";
                        OffsetArrayString += Convert.ToString(OffsetCount, 10);
                        OffsetArrayString += "\r\n};";
                                                
                        WidthArrayString += "\r\n};";
                        HeightArrayString += "\r\n};";
                        ArrayOfArraysString += "\r\n};";
                    }
                    else
                    {
                        CharacterIndexString += ", \r\n\t";
                        MixedWidthAndEncodingArrayString += ", \r\n\t";
                        EncodingMethordArrayString += ", \r\n\t";
                        RleByteCountString += ", \r\n\t";
                        OffsetArrayString += ", \r\n\t";
                        WidthArrayString += ", \r\n\t";
                        HeightArrayString += ", \r\n\t";
                        ArrayOfArraysString += ", \r\n\t";
                    }

                    ColumnLoop = 0;
                    
                }
                else
                {
                    if (CharCounter == (m_TotalCharacters - 1))
                    {
                        CharacterIndexString += "\r\n};";
                        MixedWidthAndEncodingArrayString += "\r\n};";
                        EncodingMethordArrayString += "\r\n};";
                        RleByteCountString += "\r\n};";

                        // Add one Last dummy Offset Value
                        OffsetArrayString += ", ";
                        OffsetArrayString += Convert.ToString(OffsetCount, 10);
                        OffsetArrayString += "\r\n};";
                                                
                        WidthArrayString += "\r\n};";
                        HeightArrayString += "\r\n};";
                        ArrayOfArraysString += "\r\n};";
                    }
                    else
                    {
                        CharacterIndexString += ", ";
                        MixedWidthAndEncodingArrayString += ", ";
                        EncodingMethordArrayString += ", ";
                        RleByteCountString += ", ";
                        OffsetArrayString += ", ";
                        WidthArrayString += ", ";
                        HeightArrayString += ", ";
                        ArrayOfArraysString += ", ";
                    }
                    
                }
            } // End of 'for' loop


            OutputString += "\r\n\r\n";
            OutputString += CharacterIndexString;

            OutputString += "\r\n\r\n";
            OutputString += OffsetArrayString;

            OutputString += "\r\n\r\n";
            OutputString += EncodingMethordArrayString;

            OutputString += "\r\n\r\n";
            OutputString += RleByteCountString;

            OutputString += "\r\n\r\n";
            OutputString += WidthArrayString;

            OutputString += "\r\n\r\n";
            OutputString += HeightArrayString;


            OutputString += "\r\n\r\n";
            OutputString += MixedWidthAndEncodingArrayString;

            OutputString += "\r\n\r\n";
            OutputString += GetLargeArrayString(OutputBase);

            OutputString += "\r\n\r\n";
            OutputString += "//******************************************************\r\n";
            OutputString += "//***     Another method of encoding the font    *******\r\n";
            OutputString += "//******************************************************\r\n";

 
            OutputString += "\r\n\r\n";
            OutputString += ArrayOfArraysString;

            return OutputString;
        }
    }

    partial class RLE_Class
    {
        public string GetLargeArrayString(int Format)
        {
            // This public method will return a large string representing the complete font in byte format.
            // The actual byte format can be Binary, Decimal or Hexadecimal.
            // RLE EncodingType 0=Vertical, 1=Horizontal 2=Mixed 
            // The EncodingType will found in the m_EncodingMethodArray[] for each character.

            

            string TempString = "";
            string LeadString;
            int CurrentByte;
            int Base;
            int Padding;
            int TxtCols;
            int TxtColCounter = 0;
            int ByteLoop;
            int ByteCount = 0;
            int EncodingMethod;
            int Totalizer = 0;
            int CharLoop;

            byte[] CurrentByteArray;

            for (CharLoop = 0; CharLoop < m_TotalCharacters; CharLoop++)
            {
                EncodingMethod = m_EncodingMethodArray[CharLoop];

                if (EncodingMethod == 1)
                {
                    ByteCount = ByteCount + m_VerticalRleByteCountArray[CharLoop];
                }
                else
                {
                    ByteCount = ByteCount + m_HorizontalRleByteCountArray[CharLoop];
                }
            }

            TempString = "\r\n\r\n// The 'Large-Font-Array' holds the complete font";
            TempString += "\r\n// If your program uses this array the OffsetArray,";
            TempString += "\r\n// holds each characters byte offset count into this Array.";
            TempString += "\r\nconst unsigned char LargeFontArray[";
            TempString += Convert.ToString(ByteCount, 10);
            TempString += "] = \r\n{\r\n\t";
            
        
            if (Format == 16)
            {
                LeadString = "0x";
                Base = 16;
                Padding = 2;
                TxtCols = 10;
            }
            else
            {
                if (Format == 2)
                {
                    LeadString = "0b";
                    Base = 2;
                    Padding = 8;
                    TxtCols = 5;
                }
                else
                {
                    LeadString = "";
                    Base = 10;
                    Padding = 0;
                    TxtCols = 10;
                }
            }

            

            
            

            for (CharLoop = 0; CharLoop < m_TotalCharacters; CharLoop++)
            {
                EncodingMethod = m_EncodingMethodArray[CharLoop];

                if (EncodingMethod == 1)
                {
                    CurrentByteArray = m_ArrayOfVerticalArrays[CharLoop];
                    ByteCount = m_VerticalRleByteCountArray[CharLoop];
                }
                else
                {
                    CurrentByteArray = m_ArrayOfHorizontalArrays[CharLoop];
                    ByteCount = m_HorizontalRleByteCountArray[CharLoop];
                }

             

               

                for (ByteLoop = 0; ByteLoop < ByteCount; ByteLoop++)
                {
                    TxtColCounter++;
                    Totalizer++;
                    CurrentByte = CurrentByteArray[ByteLoop];

                    TempString += LeadString;
                    TempString += Convert.ToString(CurrentByte, Base).PadLeft(Padding, '0');

                    if (TxtColCounter == TxtCols)
                    {
                        if (ByteLoop < (ByteCount - 1))
                        {
                            // End of Line but more bytes to go
                            TempString += ", \r\n\t";
                        }
                        else
                        {
                            if ((CharLoop + 1) < m_TotalCharacters)
                            {
                                // End of Line and End of bytes, but more characters to go
                                TempString += ", \r\n\t";


                            }
                            else
                            {
                                // End of Line and End of bytes and no more characters
                                TempString += "\r\n";
                            }
                        }

                        TxtColCounter = 0;
                    }
                    else
                    {
                        if (ByteLoop < (ByteCount - 1))
                        {
                            // Middle of Line with more bytes to go
                            TempString += ", ";
                        }
                        else
                        {
                            if ((CharLoop + 1) < m_TotalCharacters)
                            {
                                // Middle of Line and End of bytes, but more characters to go
                                TempString += ", ";
                            }
                            else
                            {
                                // Middle of Line and End of bytes and no more characters
                                TempString += "\r\n";                                
                            }
                            
                        }

                    }
                }
            }

            //Totalizer = Totalizer + 1;
            TempString += "}; // A total of ";
            TempString += Convert.ToString(Totalizer, 10);
            TempString += " bytes";
            TempString += "\r\n\r\n";
            return TempString;
        }
    }

    partial class RLE_Class
    {
        public string GetMultipleArrayString(int Format)
        {
            // This public method will return a string of arrays, 1 array for each character in the font.
            // The actual byte format can be Binary, Decimal or Hexadecimal.
            // The EncodingType for each character will be found in the m_EncodingMethodArray[].
            // RLE EncodingType 0=Vertical, 1=Horizontal 2=Mixed 



            string TempString = "";
            string LeadString;
            string AsciiString;
            int CurrentByte;
            int Base;
            int Padding;
            int TxtCols;
            int TxtColCounter = 0;
            int ByteLoop;
            int ByteCount;
            int EncodingMethod;
            int Totalizer = 0;

            byte[] CurrentByteArray;

            TempString = "\r\n\r\n// Each of the following arrays holds the RLE bytes for one font character";
            TempString += "\r\n// If your program uses these arrays they are accesed with the MainStringArray,";
            TempString += "\r\n// which is an Array of these arrays in ascii order.";
            TempString += "\r\n\r\n";


            if (Format == 16)
            {
                LeadString = "0x";
                Base = 16;
                Padding = 2;
                TxtCols = 10;
            }
            else
            {
                if (Format == 2)
                {
                    LeadString = "0b";
                    Base = 2;
                    Padding = 8;
                    TxtCols = 5;
                }
                else
                {
                    LeadString = "";
                    Base = 10;
                    Padding = 0;
                    TxtCols = 10;
                }
            }

            int CharLoop;


            for (CharLoop = 0; CharLoop < m_TotalCharacters; CharLoop++)
            {
                EncodingMethod = m_EncodingMethodArray[CharLoop];

                if (EncodingMethod == 1)
                {
                    CurrentByteArray = m_ArrayOfVerticalArrays[CharLoop];
                    ByteCount = m_VerticalRleByteCountArray[CharLoop];
                }
                else
                {
                    CurrentByteArray = m_ArrayOfHorizontalArrays[CharLoop];
                    ByteCount = m_HorizontalRleByteCountArray[CharLoop];
                }

                AsciiString = Convert.ToString(m_CharValueArray[CharLoop], 16);
                AsciiString = AsciiString.ToUpper();

                TempString += "\r\n\r\n";
                TempString += "const unsigned char Chr";
                TempString += AsciiString;
                TempString += "[";
                TempString += Convert.ToString(ByteCount, 10);
                TempString += "] = \r\n{\r\n\t";

                TxtColCounter = 0;

               

                for (ByteLoop = 0; ByteLoop < ByteCount; ByteLoop++)
                {
                    TxtColCounter++;
                    Totalizer++;
                    CurrentByte = CurrentByteArray[ByteLoop];

                    TempString += LeadString;
                    TempString += Convert.ToString(CurrentByte, Base).PadLeft(Padding, '0');

                    if (TxtColCounter == TxtCols)
                    {
                        if (ByteLoop < (ByteCount - 1))
                        {
                            // End of Line but more bytes to go
                            TempString += ", \r\n\t";
                        }
                        else
                        {
                            if ((CharLoop + 1) < m_TotalCharacters)
                            {
                                // End of Line and End of bytes, but more characters to go
                                TempString += "\r\n};"; // Terminate Array 


                            }
                            else
                            {
                                // End of Line and End of bytes and no more characters
                                TempString += "\r\n};"; // Terminate Array 
                            }
                        }

                        TxtColCounter = 0;
                    }
                    else
                    {
                        if (ByteLoop < (ByteCount - 1))
                        {
                            // Middle of Line with more bytes to go
                            TempString += ", "; 
                        }
                        else
                        {
                            if ((CharLoop + 1) < m_TotalCharacters)
                            {
                                // Middle of Line and End of bytes, but more characters to go
                                TempString += "\r\n};"; // Terminate Array
                            }
                            else
                            {
                                // Middle of Line and End of bytes and no more characters
                                TempString += "\r\n};"; // Terminate Array 
                            }

                        }

                    }
                }
            }

            
            return TempString;
        }
    }

    partial class RLE_Class
    {
        private string CreateRleByteString(char ThisChar, int ByteCount, int Format, byte[] ByteArray, string EncodingName)
        {
            // Cycle through the ByteArray using it's contents to
            // create a string to represent the code needed to paste
            // into the users own program code.

            string TempString;
            string LeadString;
            int CurrentByte;
            int Base;
            int Padding;
            int TxtCols;
            int TxtColCounter = 0;
            int ByteLoop;

            //data = new string[1];

            TempString = "\r\n\t";
            TempString += "// ";
            TempString += EncodingName;
            TempString += " RLE byte count for character '";
            TempString += ThisChar;
            //  TempString += Convert.ToString(ThisChar, ThisChar);
            TempString += "' ";
            TempString += Convert.ToString(ByteCount, 10);
            TempString += "\r\n";
            TempString += "\r\n\t";





            if (Format == 16)
            {
                LeadString = "0x";
                Base = 16;
                Padding = 2;
                TxtCols = 10;
            }
            else
            {
                LeadString = "0b";
                Base = 2;
                Padding = 8;
                TxtCols = 5;
            }



            for (ByteLoop = 0; ByteLoop < ByteCount; ByteLoop++)
            {
                TxtColCounter++;
                CurrentByte = ByteArray[ByteLoop];

                TempString += LeadString;
                TempString += Convert.ToString(CurrentByte, Base).PadLeft(Padding, '0');

                if (TxtColCounter == TxtCols)
                {
                    if (ByteLoop < (ByteCount - 1))
                    {
                        TempString += ", \r\n\t";
                    }
                    else
                    {
                        TempString += "\r\n";
                        TempString += "\r\n\t";
                    }

                    TxtColCounter = 0;
                }
                else
                {
                    if (ByteLoop < (ByteCount - 1))
                    {
                        TempString += ", ";
                    }
                    else
                    {
                        TempString += "\r\n";
                        TempString += "\r\n\t";
                    }

                }
            }

            return TempString;

        }// End of CreateRleByteString()
    }// End of partial class RLE_Class

    partial class RLE_Class
    {
        private int FillRleByteArray(int TotalPixels, bool[] PixelArray, byte[] ByteArray)
        {
            // This method works for Vertical and Horizontal arrays.
            // Go through the procedure of creating the RLE bytes.
            // But if (ByteArray = null) don't store the bytes, but just return byte count.
            


            bool BitType = PixelArray[0];
            int PixelArrayCounter;
            int BytesCreated = 0;
            int BitCounter = 0;


          
            for (PixelArrayCounter = 0; PixelArrayCounter < TotalPixels; PixelArrayCounter++)
            {
                if (PixelArray[PixelArrayCounter] == BitType)
                {
                    if (BitCounter < 127)
                    {
                        BitCounter++;
                    }
                    else
                    {
                        if (ByteArray != null)
                        {
                            if (BitType == true)
                            {
                                ByteArray[BytesCreated] = (byte)(BitCounter + 128);
                            }
                            else
                            {
                                ByteArray[BytesCreated] = (byte)BitCounter;
                            }
                        }

                        BytesCreated++;
                        BitCounter = 1;
                    }
                }
                else
                {
                    if (BitType == true)
                    {
                        if (ByteArray != null)
                        {
                            ByteArray[BytesCreated] = (byte)(BitCounter + 128);
                        }
                        BitType = false;
                    }
                    else
                    {
                        if (ByteArray != null)
                        {
                            ByteArray[BytesCreated] = (byte)BitCounter;
                        }
                        BitType = true;
                    }

                    BytesCreated++;
                    BitCounter = 1;

                }
            }

            if (ByteArray != null)
            {
                if (BitType == true)
                {
                    ByteArray[BytesCreated] = (byte)(BitCounter + 128);
                }
                else
                {
                    ByteArray[BytesCreated] = (byte)BitCounter;
                }
            }

            BytesCreated++;

            return BytesCreated;
        }
    }


    partial class RLE_Class
    {
        // Fill the bool array with bits representing the character pixels taken VERTICALLY from the character "page array"
        // true = foreground pixel, false = background pixel.

        private void FillVerticalPixelArray(int width, int height, int colCount, int rowCount, ArrayList pages, bool[] VertPixelArray)
        {
            int TotalPixels = width * height;
            int CurrentByte;
            int BitValue;
            int PixelArrayCounter = 0;
            int PixelColumn = 0;
            int TotalByteColumns = colCount;
            int ColumnByte;
            int CurrentByteIndex = 0;
            int Row;
            int BitIndex = 0;


            for (PixelColumn = 0; PixelColumn < width; PixelColumn++)
            {
                if (BitIndex > 0)
                {
                    BitIndex--;
                }
                else
                {
                    BitIndex = 7;
                }

                ColumnByte = (PixelColumn / 8);

                for (Row = 0; Row < rowCount; Row++)
                {
                    CurrentByteIndex = ColumnByte + (TotalByteColumns * Row);

                    CurrentByte = (byte)pages[CurrentByteIndex];

                    BitValue = (CurrentByte & (1 << BitIndex));

                    if (BitValue > 0)
                    {
                        VertPixelArray[PixelArrayCounter] = true;
                    }
                    else
                    {
                        VertPixelArray[PixelArrayCounter] = false;
                    }

                    PixelArrayCounter++;
                }
            }

        }// End of FillVerticalPixelArray()
    }// End of partial class RLE_Class

    partial class RLE_Class
    {
        // Fill the bool array with bits representing the character pixels taken HORIZONTALLY from the character "page array"
        // true = foreground pixel, false = background pixel.

        private void FillHorizontalPixelArray(int width, int height, int colCount, int rowCount, ArrayList pages, bool[] HorizPixelArray)
        {
            int CurrentByte;
            int BitValue;
            int ByteCounter;
            int BitCounter;
            int PixelWidthCounter = 0;
            int PixelArrayCounter = 0;


            for (ByteCounter = 0; ByteCounter < pages.Count; ByteCounter++)
            {
                CurrentByte = (byte)pages[ByteCounter];

                for (BitCounter = 8; BitCounter > 0; BitCounter--)
                {

                    BitValue = (CurrentByte & (1 << (BitCounter - 1)));


                    if (BitValue > 0)
                    {
                        HorizPixelArray[PixelArrayCounter] = true;
                    }
                    else
                    {
                        HorizPixelArray[PixelArrayCounter] = false;
                    }

                    PixelWidthCounter++;
                    PixelArrayCounter++;

                    if (PixelWidthCounter == width)
                    {
                        PixelWidthCounter = 0;
                        break;
                    }


                }

            }

        }// End of FillHorizontalPixelArray()
    }// End of partial class RLE_Class


    partial class RLE_Class
    {
        private string CreateHorizontalVisualizerString(char ON, char OFF, int width, int height, byte[] ByteArray, int ByteCount)
        {
            string Start = "//\t ";
            string End = "\r\n";

            string TempString;
            TempString = End;
            TempString += Start;
            TempString += "HorizontalVisualizer";
            TempString += End;
            TempString += End;
            TempString += Start;


            int ByteCounter = 0;
            char BitChar = ON;

            int TotalPixels = width * height;
            int Pixcounter = 0;
            int LineLength = 0;
            int BitBucket = 0;

            while (true)
            {


                if (BitBucket > 0)
                {
                    if (LineLength < width)
                    {
                        TempString += BitChar;
                        Pixcounter++;
                        LineLength++;
                        BitBucket--;
                    }
                    else
                    {
                        TempString += End;
                        TempString += Start;
                        LineLength = 0;
                    }
                }
                else
                {
                    if (ByteCounter < ByteCount)
                    {
                        if (ByteArray[ByteCounter] > 127)
                        {
                            BitChar = ON;
                            BitBucket = ByteArray[ByteCounter] - 128;
                        }
                        else
                        {
                            BitChar = OFF;
                            BitBucket = ByteArray[ByteCounter];
                        }

                        ByteCounter++;
                    }
                    else
                    {
                        // We have used bytes all bytes available
                        TempString += End;
                        break;
                    }
                }
            }

            Pixcounter = Pixcounter + 1;

            return TempString;


        }// End of CreateHorizontalVisualizerString()
    }// End of partial class RLE_Class

    partial class RLE_Class
    {
        private string CreateVerticalVisualizerString(char ON, char OFF, int width, int height, byte[] ByteArray, int ByteCount)
        {
            int TotalPixels = width * height;
            bool[] PixelArray = new bool[TotalPixels];
            string[] StringArray = new string[height];

            int PixelCounter = 0;
            int PixelLoop;
            int ByteLoop;
            int BitCount;
           
            bool BitVal;

            
            int HeightLoop;

            string FullString;

            for (ByteLoop = 0; ByteLoop < ByteCount; ByteLoop++)
            {
                BitCount = ByteArray[ByteLoop];
                BitVal = false;

                if (BitCount > 128)
                {
                    BitCount = BitCount - 128;
                    BitVal = true;
                }

                for (PixelLoop = 0; PixelLoop < BitCount; PixelLoop++)
                {
                    PixelArray[PixelCounter] = BitVal;
                    PixelCounter++;
                }
            }

            PixelCounter = 0;

            for (HeightLoop = 0; HeightLoop < height; HeightLoop++)
            {
                StringArray[HeightLoop] = "\r\n//\t";
            }

            while (PixelCounter < TotalPixels)
            {
                for (HeightLoop = 0; HeightLoop < height; HeightLoop++)
                {
                    if (PixelArray[PixelCounter] == true)
                    {
                        StringArray[HeightLoop] += ON;
                    }
                    else
                    {
                        StringArray[HeightLoop] += OFF;
                    }

                    PixelCounter++;
                }
            }

            FullString = "\r\n//\tVertical - Visualizer\r\n";

            for (HeightLoop = 0; HeightLoop < height; HeightLoop++)
            {
                FullString += StringArray[HeightLoop];
            }

            return FullString;

        }// End of CreateVerticalVisualizerString()
    }// End of partial class RLE_Class

} //namespace TheDotFactory