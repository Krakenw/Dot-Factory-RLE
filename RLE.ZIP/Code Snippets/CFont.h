
//  CFont.h


#ifndef CFONT_H_
#define CFONT_H_

struct CharInfoStruct
{
	bool IsVertical;
	unsigned short ByteCount;
	unsigned char CharWidth;
	unsigned char CharHeight;
	const unsigned char* pCharPointer;
};

class CFont
{
public:

	CFont(){};
	virtual ~CFont(){};

	virtual bool PrepareFontCharacter(unsigned char ThisChar){return false;};

	virtual bool PrepareFontCharacter(unsigned char ThisChar, CharInfoStruct* pInfo){return false;};

	virtual int GetCharByteCount(void){return 0;};
	virtual int GetCharOrientation(void){return 0;};
	virtual int GetCharWidth(void){return 0;};
	virtual int GetCharHeight(void){return 0;};
	virtual const unsigned char* GetCharPointer(void){return 0;};

};

#endif /* CFONT_H_ */
