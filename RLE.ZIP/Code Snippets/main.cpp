

// main.cpp



#include "stm32f4xx.h"



#include "SSD1963.h"

#include "CFullFont.h"

#include "CNumericFont72.h"

#include "Colours.h"




CFullFont g_FullFont;

CNumericFont72 g_NumericFont72;

SSD1963 g_SSD;





int main(void)
{

	g_SSD.SSD1963_PutcRLE(&g_NumericFont72, '8', 100, 100, MyBlack, MyWhite);


	g_SSD.SSD1963_PutsRLE(&g_FullFont, "123456", 130, 280, MyBlack, MyWhite, 5);


}

