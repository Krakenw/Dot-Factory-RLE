
//extended initializer lists only available with -std=c++11 or -std=gnu++11

// #include "CNumericFont72.h"

//	 This font has been encoded with 'The Dot Factory'
//	 using Run-Length-Encoding (RLE) from a 72-Pt
//	 TrueType font called "Monofonto"

//	bool PrepareFontCharacter(unsigned char ThisChar)
//	int GetCharByteCount(void)
//	int GetCharOrientation(void)
//	int GetCharWidth(void)
//	int GetCharHeight(void)
//	const unsigned char* GetCharPointer(void)


// CharacterIndexArray
// OffsetArray
// EncodingMethodArray
// ByteCount
// const unsigned charCharWidthArray				(Not used - because Width & Height are fixed in this font)
// const unsigned char CharHeightArray				(Not used - because Width & Height are fixed in this font)
// const unsigned char MixedWidthAndEncodingArray	(Not used - because Width & Height are fixed in this font)
// LargeFontArray

#ifndef CNUMERICFONT72_H_
#define CNUMERICFONT72_H_

#include "CFont.h"

class CNumericFont72: public CFont
{
public:


	CNumericFont72(){};

	virtual ~CNumericFont72(){};

	bool PrepareFontCharacter(unsigned char ThisChar)
	{
		int loop;
		unsigned char TestChar;

		for(loop = 0; loop < m_TotalCharCount; loop++)
		{
			TestChar = CharacterIndexArray[loop];

			if(TestChar == ThisChar)
			{
				ValidCharIndex = loop;
				return true;
			}
		}

		ValidCharIndex = 0;
		return false;
	}

	virtual bool PrepareFontCharacter(unsigned char ThisChar, CharInfoStruct* pInfo)
	{
		int loop;
		unsigned char TestChar;

		for(loop = 0; loop < m_TotalCharCount; loop++)
		{
			TestChar = CharacterIndexArray[loop];

			if(TestChar == ThisChar)
			{
				ValidCharIndex = loop;
				pInfo->IsVertical = GetCharOrientation();
				pInfo->CharHeight = GetCharHeight();
				pInfo->CharWidth = GetCharWidth();
				pInfo->ByteCount = GetCharByteCount();
				pInfo->pCharPointer = GetCharPointer();
				return true;
			}
		}

		ValidCharIndex = 0;
		return false;
	};

	int GetCharByteCount(void)
	{
		return OffsetArray[ValidCharIndex +1] - OffsetArray[ValidCharIndex];
	}

	int GetCharOrientation(void)
	{
		return EncodingMethodArray[ValidCharIndex];

		//return ((MixedWidthAndEncodingArray[ValidCharIndex]) && (1 << 7));
	}

	int GetCharWidth(void)
	{
		return CharWidth;

		//return CharWidthArray[ValidCharIndex];

		//unsigned char Width = (MixedWidthAndEncodingArray[ValidCharIndex] << 1);
		//return (Width >> 1);
	}

	int GetCharHeight(void)
	{
		return CharHeight;

		//return CharHeightArray[ValidCharIndex];
	}

	const unsigned char* GetCharPointer(void)
	{
		return &LargeFontArray[OffsetArray[ValidCharIndex]];
	}

private:

	volatile int ValidCharIndex = 0;
	const unsigned char CharWidth = 43;
	const unsigned char CharHeight = 84;
	const unsigned int m_TotalCharCount = 15;

//******************************************************************
//*****				Font Arrays start here				************
//******************************************************************


	//	      ***    Font Encoding Statistics    ***
	//
	//	 This font has been encoded with 'The Dot Factory'
	//	 using Run-Length-Encoding (RLE) from a 72-Pt
	//	 TrueType font called "Monofonto"

	//	'+' (Ascii 43) has the smallest width at 43 Pixels Wide
	//	'+' (Ascii 43) has the greatest width at 43 Pixels Wide
	//	'+' (Ascii 43) has the smallest height at 84 Pixels high
	//	'+' (Ascii 43) has the greatest height at 84 Pixels high

	//	 The total Horizontal RLE bytes created for this font = 2183
	//	 The total Vertical RLE bytes created for this font = 1653
	//	 The total Vert+Horiz RLE bytes created for this font = 1619
	//	 The total Continuous Bitmap bytes created for this font = 6328
	//	 The total Standard Bitmap bytes created for this font = 7056



	// The 'CharacterIndexArray' Resolves the Index of a character.
	// It is useful when only a 'partial' Character set is generated.
	// Search this array for the ASCII character value you wish to print.
	// If you find the value, the index of where you found it will be
	// the zero based index of most other arrays pertaining to
	// that particular ASCII character.

	// If you do NOT find the ASCII character value, Then that character
	// was NOT encoded in the font.

	const unsigned char CharacterIndexArray[14] =
	{
		43, 44, 45, 46, 48,
		49, 50, 51, 52, 53,
		54, 55, 56, 57
	};



	// The 'Offset-Array'
	// When your font is stored in one Large-Array the OffsetArray,
	// holds each characters byte offset count into the Large-Array.
	// The last value is a 'dummy' value used to define the last characters length.
	const unsigned int OffsetArray[15] =
	{
		0, 86, 134, 179, 224,
		331, 391, 555, 726, 843,
		1018, 1165, 1294, 1473, 1619
	};


	// The 'EncodingMethodArray' indicates the RLE method used to
	// encode each character (1 = Vertical,  0 = Horizontal)
	// It is useful when the font uses both Vertical & Horizontal Encoding

	const unsigned char EncodingMethodArray[14] =
	{
		1, 1, 0, 1, 1,
		1, 1, 1, 1, 0,
		1, 1, 1, 1
	};



	// The 'ByteCount-Array'
	// This array holds the number of bytes used to code each characters pixels.
	// If you are using one Large-Array these values can be determined from
	// the OffsetArray, but if you are using the ArrayOfArrays method, this array
	// can be used to determine the size of the arrays inside the ArrayOfArrays.
	const unsigned int ByteCount[14] =
	{
		86, 48, 45, 45, 107,
		60, 164, 171, 117, 175,
		147, 129, 179, 146
	};





	// The 'Mixed-Width-And-Encoding-Array'
	// It is useful when the font uses both Vertical & Horizontal Encoding
	// This array is only valid for font widths less than 128 pixels
	// The MSB (bit 7) indicates encoding method (1 = Vertical,  0 = Horizontal)
	// Bits 0-6 represent the character width.
	const unsigned char MixedWidthAndEncodingArray[14] =
	{
		171, 171, 43, 171, 171,
		171, 171, 171, 171, 43,
		171, 171, 171, 171
	};



	// The 'Large-Font-Array' holds the complete font
	// If your program uses this array the OffsetArray,
	// holds each characters byte offset count into this Array.
	const unsigned char LargeFontArray[1619] =
	{
		32, 136, 76, 136, 76, 136, 76, 136, 76, 136,
		76, 136, 76, 136, 76, 136, 76, 136, 76, 136,
		76, 136, 76, 136, 76, 136, 76, 136, 76, 136,
		76, 136, 76, 136, 59, 171, 41, 171, 41, 171,
		41, 171, 41, 171, 41, 171, 41, 171, 41, 171,
		58, 136, 76, 136, 76, 136, 76, 136, 76, 136,
		76, 136, 76, 136, 76, 136, 76, 136, 76, 136,
		76, 136, 76, 136, 76, 136, 76, 136, 76, 136,
		76, 136, 76, 136, 127, 1, 127, 127, 127, 127,
		127, 127, 127, 127, 127, 30, 129, 77, 135, 69,
		144, 61, 151, 57, 155, 58, 154, 58, 155, 57,
		155, 57, 155, 58, 150, 62, 145, 67, 141, 71,
		136, 77, 130, 127, 127, 127, 127, 127, 127, 127,
		127, 127, 127, 97, 127, 127, 127, 127, 127, 127,
		127, 127, 127, 127, 69, 158, 13, 158, 13, 158,
		13, 158, 13, 158, 13, 158, 13, 158, 13, 158,
		13, 158, 13, 158, 127, 127, 127, 127, 127, 127,
		127, 127, 127, 127, 127, 127, 127, 127, 78, 127,
		127, 127, 127, 127, 127, 127, 127, 127, 127, 51,
		135, 75, 139, 72, 141, 71, 142, 69, 143, 69,
		143, 69, 143, 69, 143, 70, 142, 70, 141, 72,
		139, 75, 135, 127, 127, 127, 127, 127, 127, 127,
		127, 127, 127, 90, 127, 127, 9, 178, 31, 184,
		27, 186, 24, 190, 21, 192, 19, 194, 18, 194,
		17, 196, 16, 196, 15, 198, 14, 198, 14, 143,
		40, 143, 13, 141, 46, 141, 12, 140, 48, 140,
		12, 140, 48, 140, 12, 139, 50, 139, 12, 139,
		50, 139, 12, 139, 50, 139, 12, 139, 50, 139,
		12, 139, 50, 139, 12, 139, 50, 139, 12, 140,
		48, 140, 12, 140, 48, 140, 12, 141, 46, 141,
		13, 143, 40, 143, 14, 198, 14, 198, 15, 196,
		16, 196, 17, 194, 18, 194, 19, 192, 21, 190,
		23, 188, 26, 184, 31, 178, 40, 166, 127, 127,
		27, 127, 127, 127, 127, 9, 140, 71, 141, 71,
		140, 71, 141, 71, 140, 71, 140, 71, 141, 71,
		140, 71, 141, 71, 140, 71, 140, 72, 140, 71,
		193, 18, 194, 18, 194, 17, 195, 17, 195, 16,
		196, 16, 196, 15, 197, 15, 197, 14, 198, 13,
		199, 127, 127, 127, 127, 127, 127, 127, 127, 127,
		46, 127, 59, 131, 76, 136, 49, 129, 23, 139,
		47, 131, 21, 141, 45, 133, 19, 143, 43, 135,
		18, 144, 41, 137, 17, 145, 39, 139, 16, 146,
		37, 141, 16, 146, 36, 142, 15, 147, 34, 144,
		15, 147, 32, 146, 14, 148, 30, 148, 14, 143,
		33, 150, 14, 141, 33, 152, 13, 141, 32, 154,
		13, 140, 32, 155, 13, 139, 31, 157, 13, 139,
		29, 159, 13, 139, 27, 161, 13, 139, 25, 163,
		13, 139, 23, 151, 1, 141, 13, 139, 21, 151,
		3, 141, 13, 140, 19, 150, 5, 141, 13, 140,
		17, 151, 6, 141, 14, 140, 14, 151, 8, 141,
		14, 142, 9, 152, 10, 141, 14, 174, 11, 141,
		15, 171, 13, 141, 15, 169, 15, 141, 16, 167,
		16, 141, 17, 164, 18, 141, 17, 162, 20, 141,
		18, 160, 21, 141, 20, 156, 23, 141, 21, 153,
		25, 141, 23, 149, 27, 141, 25, 144, 30, 141,
		29, 136, 127, 127, 58, 127, 7, 135, 77, 138,
		37, 133, 32, 140, 32, 136, 32, 142, 28, 138,
		32, 143, 26, 139, 32, 144, 23, 141, 32, 145,
		21, 142, 32, 146, 20, 142, 32, 147, 18, 143,
		32, 147, 17, 144, 32, 148, 16, 144, 38, 142,
		15, 142, 43, 141, 14, 140, 46, 140, 14, 139,
		48, 139, 14, 138, 49, 140, 12, 139, 49, 140,
		12, 138, 51, 139, 12, 138, 51, 139, 12, 138,
		51, 139, 12, 138, 20, 137, 22, 139, 12, 138,
		20, 138, 21, 139, 12, 138, 20, 138, 21, 139,
		12, 139, 18, 139, 20, 140, 12, 139, 18, 140,
		19, 140, 13, 139, 16, 142, 17, 140, 14, 140,
		14, 144, 15, 141, 14, 141, 11, 147, 12, 143,
		15, 145, 2, 153, 8, 144, 16, 196, 17, 194,
		19, 158, 1, 162, 19, 157, 2, 161, 21, 156,
		3, 159, 24, 153, 5, 157, 26, 151, 6, 156,
		29, 147, 9, 154, 32, 143, 13, 150, 39, 133,
		19, 147, 68, 141, 127, 68, 43, 141, 69, 143,
		67, 145, 65, 147, 62, 150, 60, 152, 58, 154,
		56, 156, 54, 158, 51, 147, 3, 139, 49, 147,
		5, 139, 47, 147, 7, 139, 45, 147, 9, 139,
		43, 147, 11, 139, 40, 148, 13, 139, 38, 147,
		16, 139, 36, 147, 18, 139, 34, 147, 20, 139,
		32, 147, 22, 139, 29, 148, 24, 139, 29, 146,
		26, 139, 29, 143, 29, 139, 29, 141, 31, 139,
		29, 139, 33, 139, 29, 137, 35, 154, 14, 198,
		14, 198, 14, 198, 14, 198, 14, 198, 14, 198,
		14, 198, 14, 198, 14, 198, 14, 198, 58, 139,
		73, 139, 73, 139, 73, 139, 73, 139, 73, 139,
		73, 139, 112, 46, 163, 8, 163, 8, 163, 8,
		163, 8, 163, 8, 163, 8, 163, 8, 163, 8,
		163, 8, 163, 8, 163, 8, 163, 8, 138, 33,
		138, 33, 138, 33, 138, 33, 138, 33, 138, 33,
		138, 33, 138, 33, 138, 33, 138, 33, 138, 33,
		138, 33, 138, 33, 138, 33, 138, 6, 137, 18,
		138, 3, 143, 15, 138, 1, 146, 14, 159, 12,
		160, 11, 161, 10, 162, 9, 162, 9, 163, 8,
		164, 7, 164, 7, 142, 7, 143, 7, 141, 10,
		142, 6, 139, 13, 141, 6, 139, 14, 140, 31,
		140, 32, 140, 31, 140, 31, 140, 31, 140, 31,
		140, 31, 140, 31, 140, 31, 140, 31, 140, 12,
		129, 18, 140, 10, 132, 17, 140, 8, 134, 16,
		140, 8, 136, 14, 141, 6, 139, 13, 141, 4,
		142, 10, 142, 6, 143, 6, 144, 6, 165, 7,
		163, 8, 163, 9, 161, 10, 160, 12, 159, 12,
		158, 14, 156, 16, 154, 18, 151, 22, 148, 25,
		144, 30, 137, 127, 127, 127, 127, 27, 127, 1,
		139, 68, 147, 62, 153, 57, 157, 53, 160, 50,
		163, 47, 166, 44, 169, 41, 172, 38, 175, 36,
		177, 33, 179, 31, 155, 11, 144, 28, 156, 13,
		143, 26, 156, 17, 141, 24, 157, 19, 141, 22,
		158, 19, 141, 20, 159, 21, 140, 18, 161, 21,
		140, 16, 152, 1, 138, 21, 140, 14, 152, 3,
		138, 21, 140, 13, 151, 5, 138, 21, 140, 13,
		149, 7, 138, 21, 140, 13, 147, 9, 139, 19,
		141, 13, 146, 10, 139, 18, 142, 13, 144, 12,
		140, 17, 141, 14, 142, 14, 141, 14, 143, 14,
		140, 17, 142, 11, 144, 14, 138, 19, 146, 3,
		147, 15, 136, 21, 168, 15, 135, 23, 166, 16,
		133, 25, 165, 17, 131, 28, 164, 17, 129, 31,
		162, 50, 161, 53, 158, 55, 155, 59, 151, 63,
		147, 69, 139, 127, 70, 85, 140, 72, 140, 72,
		140, 72, 140, 57, 129, 14, 140, 55, 131, 14,
		140, 52, 134, 14, 140, 49, 137, 14, 140, 47,
		139, 14, 140, 44, 142, 14, 140, 41, 145, 14,
		140, 39, 147, 14, 140, 36, 150, 14, 140, 33,
		153, 14, 140, 31, 155, 14, 140, 28, 158, 14,
		140, 25, 161, 14, 140, 23, 163, 14, 140, 20,
		166, 14, 140, 17, 166, 17, 140, 15, 165, 20,
		140, 12, 165, 23, 140, 10, 165, 25, 140, 7,
		165, 28, 140, 4, 165, 31, 140, 2, 164, 34,
		175, 37, 172, 40, 169, 43, 166, 46, 163, 49,
		160, 52, 157, 55, 154, 58, 151, 61, 148, 64,
		146, 66, 143, 69, 140, 72, 137, 75, 134, 78,
		131, 81, 129, 82, 127, 2, 141, 68, 147, 38,
		137, 16, 151, 32, 144, 12, 154, 28, 148, 9,
		156, 25, 152, 6, 158, 23, 154, 4, 160, 21,
		156, 2, 162, 19, 157, 2, 162, 18, 195, 16,
		196, 16, 171, 10, 144, 14, 143, 8, 147, 14,
		142, 14, 141, 12, 144, 16, 141, 14, 139, 15,
		142, 18, 140, 13, 140, 16, 140, 20, 140, 12,
		139, 18, 139, 20, 140, 12, 138, 20, 137, 22,
		139, 12, 138, 20, 137, 22, 139, 12, 138, 20,
		137, 22, 139, 12, 138, 20, 137, 22, 139, 12,
		138, 20, 137, 22, 139, 12, 138, 20, 137, 22,
		139, 12, 139, 18, 139, 20, 140, 12, 139, 18,
		139, 20, 140, 13, 139, 16, 141, 18, 141, 13,
		141, 13, 143, 16, 141, 14, 143, 9, 146, 14,
		142, 15, 171, 10, 144, 15, 196, 17, 195, 18,
		158, 1, 162, 20, 156, 2, 162, 21, 154, 4,
		160, 23, 152, 6, 158, 26, 148, 9, 156, 29,
		144, 12, 154, 34, 137, 16, 151, 63, 147, 67,
		142, 127, 67, 101, 139, 69, 147, 63, 151, 59,
		155, 55, 158, 53, 160, 51, 162, 31, 129, 17,
		164, 28, 131, 17, 165, 25, 133, 16, 166, 23,
		135, 15, 168, 21, 136, 15, 168, 19, 138, 14,
		145, 10, 142, 17, 140, 14, 143, 14, 141, 14,
		142, 14, 141, 17, 140, 12, 144, 14, 141, 18,
		139, 11, 145, 13, 141, 19, 139, 9, 147, 13,
		140, 21, 138, 7, 149, 13, 140, 21, 138, 5,
		151, 13, 140, 21, 138, 3, 152, 14, 140, 21,
		138, 2, 151, 16, 140, 21, 161, 18, 140, 21,
		159, 20, 141, 19, 158, 22, 141, 19, 157, 24,
		141, 17, 156, 26, 142, 15, 155, 28, 144, 11,
		155, 31, 147, 3, 157, 33, 178, 35, 175, 38,
		172, 41, 169, 44, 166, 47, 163, 50, 160, 53,
		157, 57, 153, 62, 147, 68, 139, 127, 97
	}; // A total of 1619 bytes



//******************************************************************
//*****				Font Arrays end here				************
//******************************************************************

};

#endif /* CNUMERICFONT72_H_ */
