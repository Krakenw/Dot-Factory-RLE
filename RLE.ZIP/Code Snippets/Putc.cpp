
unsigned char DisplayClass::PutcRLE(CFont* pFont, char ch, uint16_t PosX, uint16_t PosY, uint16_t Fcolor, uint16_t Bcolor)
{

	CharInfoStruct CharInfo;



	if(pFont->PrepareFontCharacter(ch, &CharInfo) == false)
		return 0;

	int RleByteCount = CharInfo.ByteCount;
	int Orientation = CharInfo.IsVertical;
	int CharHeight = CharInfo.CharHeight;
	int CharWidth = CharInfo.CharWidth;

	const unsigned char* pCharPointer = CharInfo.pCharPointer;

	uint16_t PixelCount = CharWidth * CharHeight;


	m_pSSD1963_HAL->WriteCommand(SSD1963_SET_ADDRESS_MODE); // Write left to right or vice-versa

	if(Orientation == 1)
	{
		m_pSSD1963_HAL->WriteData(0b00100001); // Set the LCD Controller to vertical pixel rendering
	}
	else
	{
		m_pSSD1963_HAL->WriteData(0b00000001);	// Set the LCD Controller to Horizontal pixel rendering
	}


	m_pSSD1963_HAL->SetAreaForWriting(PosX, PosX + (CharWidth -1), PosY, PosY + CharHeight -1);

	int Byteloop;
	uint16_t PixelColor;
	unsigned char RleByte;


	for(Byteloop = 0; Byteloop < RleByteCount; Byteloop++)
	{
		RleByte = pCharPointer[Byteloop];

		if(RleByte > 128)
		{
			PixelColor = Fcolor;
			PixelCount = RleByte - 128;
		}
		else
		{
			PixelColor = Bcolor;
			PixelCount = RleByte;
		}

		while(PixelCount > 0)
		{
			m_pSSD1963_HAL->WritePixel(PixelColor);
			PixelCount--;
		}

	}

	return CharWidth;
}



int SSD1963::SSD1963_PutsRLE(CFont* pFont, const char* pStr, uint16_t PosX, uint16_t PosY, uint16_t Fcolor, uint16_t Bcolor, uint8_t Spacing)
{
	uint8_t Lenght = strlen(pStr);

	uint8_t Loop;
	uint16_t Shift = 0;

	int FontHeight = pFont->GetCharHeight();

	unsigned char CharWidth;

	for(Loop = 0; Loop < Lenght; Loop++)
	{

		CharWidth = SSD1963_PutcRLE(pFont, pStr[Loop], PosX + Shift, PosY, Fcolor, Bcolor);

		Shift = Shift + CharWidth;

		SSD1963_FillArea(PosX + Shift, PosX + Shift + Spacing, PosY, PosY + FontHeight, Bcolor);

		Shift = Shift + Spacing;
	}

	return Shift - Spacing;
}